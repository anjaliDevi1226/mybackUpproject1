package com.junitchk;

public class Calculate {
    // Method under test
	 // int add(int a, int b)-> it is like this for original code but not working for me so i have added public 
	//infrund of it
    public int add(int a, int b) {
        return a + b;
    }
}