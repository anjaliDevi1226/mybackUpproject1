package projectJunit5eg;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.*;
import com.junitchk.Person;

public class PersonTest {
	//Create Person object
	private Person persons;
	
	@BeforeEach
	void metbe() {
		persons=new Person("name1",34,10000);
	}
	@Test
	void met()
	{
		
		//increment eligibility 
		Person person_actual=persons.addeligibility(10);//method under test
		//assert
		assertEquals(11000,person_actual.getLoan_eligibility(),"Checking Loan eligibility ,after incrementing 10 percent");
		Person person_Expected=new Person("name1",34,11000);
		assertEquals(person_Expected,person_actual,"Directly checking object after incrementing salary");
	
		 
	}
}
