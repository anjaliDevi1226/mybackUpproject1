package com.ejson;

/*
 * Assignment 
 * Make changes in given JSON example to use nested object address in person class,and write the person object to file using jackson.
 */

import java.io.*;

import com.fasterxml.jackson.databind.ObjectMapper;
public class WriteJSONZEg {
	
	public static void main(String[]args) throws Exception{
		
		//Address[] address=new Address[2];
		Address[] addr= {new Address ("street1","city1",678906),
				new Address ("street2","city2",678909)};
		Person obj = new Person("Ravi",46,addr);
		obj.setName("Ravi");
		obj.setAge(40);
		
		
		ObjectMapper mapper= new ObjectMapper();
		
		FileOutputStream fos=new FileOutputStream("person.json");
		
		mapper.writeValue(fos,obj);
		String pjson=mapper.writeValueAsString(obj);
		System.out.println("Jason file create please check: "+pjson);
	}

}
