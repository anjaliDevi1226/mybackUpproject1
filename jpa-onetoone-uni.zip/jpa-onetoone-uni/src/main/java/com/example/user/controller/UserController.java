package com.example.user.controller;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.model.Profile;
import com.example.user.model.User;
import com.example.user.service.UserService;

@RestController
public class UserController {
	
	private static final Logger logger=
			LoggerFactory.getLogger(UserController.class);
	public UserController() {
		logger.info("usercontroller() contructor invoked");
	}

	@Autowired
	private UserService uService;
	
	@PostMapping
	public User createUser(@RequestBody User user) {
		logger.info("Post request is hit");
		return uService.createUser(user);
	}
	
	@GetMapping("/user/{userid}")
	public User getUser(@PathVariable long userid) {
		return uService.getUser(userid);
	}
	
	@GetMapping("/prof/{profid}")
	public Profile getProfr(@PathVariable long profid) {
		return uService.getProfile(profid);
	}
}