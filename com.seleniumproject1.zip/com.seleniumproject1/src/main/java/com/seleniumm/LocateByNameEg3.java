package com.seleniumm;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

import org.openqa.selenium.*;

public class LocateByNameEg3 {
	
	public static void main(String args[]) throws Exception{
		//set driver properties
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
		
		//create driver instance
		WebDriver driver=new ChromeDriver();
		
		//load webpage
		
		driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\LocateByNameEg3.html");
		
		//----wait until webpage loaded successfully
		//create webdriverwait
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		
			 
		//locate username ,only after it appears on webpage
		
		WebElement userNameField=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
		
		//WebElement userNameField=driver.findElement(By.name("username"));
		
		//enter text in username field 
		
		userNameField.sendKeys("Uname");
		
		//locate age
		WebElement ageField=driver.findElement(By.name("age"));
		//enter age
		
		//ageField.sendKeys("24");
		ageField.sendKeys(String.valueOf(24));
		
		//set country
		WebElement countryDropDown=driver.findElement(By.name("country"));
		
		countryDropDown.sendKeys("Canada");
		
       WebElement emailfield=driver.findElement(By.name("email"));
		
       emailfield.sendKeys("parumma@gmail.com");
		
		//locte button
		
		WebElement buttonField=driver.findElement(By.id("submitButton"));
		//click button
		buttonField.click();
		
		//----wait for message to be visible & get updated message text
		
		
		WebElement message= wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("message")));
		
				
		System.out.println("Message Displayed  :"+message.getText());
		
		Thread.sleep(3000);
		
		driver.quit();
		
	}

}
