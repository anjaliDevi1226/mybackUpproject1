package com.seleniumm;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByCSS2 {
	
	
	public static void main(String args[]) throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//create an instance of driver
		WebDriver driver=new ChromeDriver();
		//load web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\LocateByCSS.html");
	    WebElement elements=driver.findElement(By.cssSelector("form input"));
	    elements.sendKeys("somepassword");
	    System.out.println(elements.getAttribute("value"));		
	   //#4
	    List<WebElement>element=driver.findElements(By.cssSelector("input#some-id,.input-field"));
	    element.stream().forEach((e)->{System.out.println(e.getAttribute("type"));});
	    
	   
	    Thread.sleep(1000);
	    
	    //CSS Selector using AND
	    WebElement elementa=driver.findElement(By.cssSelector("input#some-id.input-field"));
	   
	    System.out.println(elementa.getTagName()+" "+elementa.getAttribute("type"));
	    Thread.sleep(1000);
	    driver.quit();
	    
	    
	}

}
