package com.seleniumm;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByCSS {
	
	
	public static void main(String args[]) throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//create an instance of driver
		WebDriver driver=new ChromeDriver();
		//load web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\LocateByCSS.html");
	    //css selector by class - use "." with the attribute 
	   // WebElement element=driver.findElement(By.cssSelector(".input-field"));
	 // WebElement element=driver.findElement(By.cssSelector("input.input-field"));
	    //css selector by id - use '#' with the attribute 
	    //if we are not giving correct special Character  then we will get NOSuchElementException
	    //WebElement element=driver.findElement(By.cssSelector("input#some-id"));
	    //CSS selector with attribute "input[type='email']"
	    WebElement elements=driver.findElement(By.cssSelector("input[type='password']"));
	    
	    //css Selector using parent child element 
	    WebElement element=driver.findElement(By.cssSelector("form input"));
	    
	    
	    element.sendKeys("testing purpose");
	    Thread.sleep(1000);
	     //elements.sendKeys("Some password");
	    
	    Thread.sleep(2000);
	    
	    System.out.println(element.getAttribute("value"));
	   // System.out.println(elements.getAttribute("value"));
	  //note : it is an input text so getText() will not work we should use getAttribute("value")
	    driver.quit();
	    
	    
	}

}
