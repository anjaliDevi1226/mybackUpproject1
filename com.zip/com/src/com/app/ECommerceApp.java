package com.app;

import com.data.Inventory;
import com.service.ShoppingCart;

import java.util.List;
import java.util.Scanner;

public class ECommerceApp {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        ShoppingCart cart = new ShoppingCart();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        
        
        while (running) {
            System.out.println("Menu:");
            System.out.println("1. Search for Products");
            System.out.println("2. Add Product to Cart");
            System.out.println("3. View Shopping Cart");
            System.out.println("4. Checkout");
            System.out.println("5. Display Available Products");
            System.out.println("6. Remove Product from Cart");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter product name : ");
                    scanner.nextLine(); 
                    String productName = scanner.nextLine();
                    inventory.searchProduct(productName);
                    break;

                case 2:
                    System.out.print("Enter Product ID: ");
                    int productId = scanner.nextInt();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    Product product = inventory.findProductById(productId);
                    if (product != null) {
                        cart.addToCart(product, quantity);
                        System.out.println("Product added to cart.");
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;

                case 3:
                    cart.viewCart();
                    break;

                case 4:
                    cart.checkout();
                    break;

                case 5:
                    cart.Display();
                    break;

                case 6:
                    System.out.print("Enter Product ID: ");
                    int removeId = scanner.nextInt();
                    System.out.print("Enter Quantity: ");
                    int quant = scanner.nextInt();
                    cart.removeFromCart(removeId, quant);
                    System.out.println("Product removed from cart.");
                    break;

                case 7:
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice,Try with valid option");
            }
        }

        scanner.close();
    }
}
