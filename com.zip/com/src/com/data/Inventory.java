
package com.data;

import com.app.Product;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Inventory {
    private List<Product> products;

    public Inventory() {
        products = new ArrayList<>();
        // Hardcode 
        products.add(new Product(1, "Mobile", "Electronics", 6000));
        products.add(new Product(2, "Washing Machine", "Electronics", 1500));
        products.add(new Product(3, "Top", "Clothing", 600));
        products.add(new Product(4, "Hair clip", "Accessories", 30));
        // Add more products as needed
    }

    public List<Product> getProducts() {
        return products;
    }

    public Product findProductById(int productId) {
        for (Product product : products) {
            if (product.getProductId() == productId) {
                return product;
            }
        }
        return null; // Product not found
    }

    public void searchProduct(String partialProdName) {
        Stream<Product> filteredProducts = products.stream()
            .filter(product -> product.getProductName().toLowerCase().contains(partialProdName.toLowerCase()));

        boolean productFound = false;

        for (Product product : filteredProducts.toList()) {
            System.out.println("Product found: " + product.getProductName() + " - $" + product.getPrice());
            productFound = true;
        }

        if (!productFound) {
            System.out.println("No products found.");
        }
    }
}
