package mockitoegg;

public interface UserRepository {
    User findById(Long userId);
}
