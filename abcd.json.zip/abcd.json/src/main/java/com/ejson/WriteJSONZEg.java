package com.ejson;

import java.io.*;

import com.fasterxml.jackson.databind.ObjectMapper;
public class WriteJSONZEg {
	
	public static void main(String[]args) throws Exception{
		
		Person obj = new Person();
		obj.setName("Ravi");
		obj.setAge(40);
		
		
		ObjectMapper mapper= new ObjectMapper();
		
		FileOutputStream fos=new FileOutputStream("person.json");
		
		mapper.writeValue(fos,obj);
	}

}
