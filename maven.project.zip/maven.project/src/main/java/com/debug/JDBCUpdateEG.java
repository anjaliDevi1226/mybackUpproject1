package com.debug;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCUpdateEG {
	private static final String DRIVER_NAME="com.mysql.cj.jdbc.Driver";
	
	public static void main(String arg[]) {
		
		
		try {
			//load driver class
			
			//Class.forName("com.mysql.cj.jdbc.Driver");
			Class.forName(DRIVER_NAME);
			
			//connect to DB server 
			Connection ct=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/sep2","root","pass@word1");
			//db name, db url,db port,jdbc string
			
			//prepare statement
		PreparedStatement ps=	ct.prepareStatement("Update messages SET ptype =? WHERE ptype=?");
		
		//set required fields in above prepared statement
		ps.setString(1,"I");
		ps.setString(2,"Internal");
		
		//execute prepared statement
		int nrces=ps.executeUpdate();
		System.out.println("Replaced "+nrces+"record with I");
		
		ps.setString(1,"E");
		ps.setString(2,"External");
		
		//execute prepared statement
		 nrces=ps.executeUpdate();
		System.out.println("Replaced "+nrces+"record with E");
		
		//close connection ,statements etc
		ps.close();
		ct.close();
		}catch(ClassNotFoundException ce) {
			
			System.out.println(ce.getMessage());
			ce.printStackTrace();
		}catch(SQLException se) {
			se.printStackTrace();
		}
	}

}
