package com.example.DemRestTemplateFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemRestTemplateFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemRestTemplateFinalApplication.class, args);
	}

}
