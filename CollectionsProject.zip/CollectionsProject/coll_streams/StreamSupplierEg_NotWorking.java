
// Java code for Stream filter 
// (Predicate predicate) to get a stream 
// consisting of the elements of this 
// stream that match the given predicate. 
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream; 

public class StreamSupplierEg_NotWorking { 

	// Driver code 
	public static void main(String[] args) 
	{ 

		// Creating a list of Integers 
		List<Integer> list = Arrays.asList(3, 4, 15, 6, 12, 20); 

		//method 2
		//above can be split into two statements as well
		Stream<String> streams = Stream.of(list.stream().filter((num) -> {return num % 5 == 0;}));
		Supplier<Stream<String>> sss = streams
		streamSupplier.get().forEach(System.out::println); 
		
		if(streamSupplier.get().allMatch((num) -> {return num % 5 == 0;}))
		{
			System.out.println("All elements in stream are divisible by 5");
		}
		else
		{
			System.out.println("Some elements in stream are not divisible by 5");
		}
	} 
} 
