import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SortedEg {
	public static void main(String[] args) {
		List<String> al = Arrays.asList("zzzzz", "kkkk", "bbbbb", "aaaa", "cccc", "mmmm"); 
		al.stream().sorted()
        .map(String::toUpperCase)
        .forEach(System.out::println);
	}
}
