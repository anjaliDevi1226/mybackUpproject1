
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PredicateSimpleEg {

    public static void main(String[] args) {

        Predicate<Integer> noLessThan6 =  x -> x < 5;

        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        List<Integer> collect = list.stream() //create stream
                .filter(noLessThan6) //filter based on predicate
                .collect(Collectors.toList()); //create a list back

        System.out.println(collect); // [6, 7, 8, 9, 10] //print the list
        
        Predicate<Integer> greaterThan10 =  x -> x > 10;
        
        // 
        boolean is_greater = list.stream().allMatch(greaterThan10);
        System.out.println(is_greater);

    }

}