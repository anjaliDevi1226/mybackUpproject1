package com.seleniumEg_pomm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainTestApp {
	
	public static void main(String[]args) throws Exception {
		//set sys property
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//create an new instance of driver
		WebDriver driver=new ChromeDriver();
		//open html page
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumEg_pomm\\src\\main\\resources\\Home.html");
		//create homepage instance
	 // create homepage instance
	 		HomePage homePage = new HomePage(driver);

	 		// on homepage click aboutlink
	 		AboutPage aboutPage = homePage.gotoAboutPage();

	 		Thread.sleep(3000);

	 		ContactPage contactPage = homePage.gotoContactPage();

	 		Thread.sleep(3000);

	 		aboutPage = contactPage.gotoAboutPage();
	 		aboutPage.showMoreInfo();
	 		Thread.sleep(2000);
	 		aboutPage.validateshowMore();
	 		// from above aboutlink goback to homepage
	 		aboutPage.gotoHomePage();
	 		Thread.sleep(3000);
	 		contactPage = aboutPage.gotoContactPage();
	 		Thread.sleep(3000);

	 		//homePage = contactPage.gotoHomePage();
	 		contactPage.fillContactForm("abcd", "dfghh@ty.com", "oiujhjhjhjhyu");
	 		contactPage.checkSubmission();
	 		Thread.sleep(3000);

	 		//homePage.gotoContactPage();
	 		
	 		

	 		driver.quit();
	}

}
