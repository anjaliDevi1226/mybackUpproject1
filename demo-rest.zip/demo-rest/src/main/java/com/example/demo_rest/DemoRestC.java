package com.example.demo_rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class DemoRestC {
	
	public DemoRestC() {
		System.out.println("constractor DemoRestC()");
	}
	
	@GetMapping("/abcd")
	String met() {
		System.out.println("-------------jjjjjjjjjjjjj-------");
		return "hello World1";
		
	}
	
	@GetMapping("/person")
	User getUser() {
		return new User(1,"person1","south street");
	}

}
